# How Reliable Is the Imāmī Ḥadīth Corpus? A Direct Rebuttal to Al-Islaah

*The Imāmī Review · Substantially rewritten critical edition · 31 October 2026*

**Editorial status:** Evidence-based critical rebuttal; research draft pending full manuscript collation and independent authentication of every cited isnād. This article responds to Syed Ali Hur Kamoonpuri’s Al-Islaah essay rather than purporting to authenticate the entirety of Shīʿī ḥadīth literature. Quotations from al-Ḥaydarī's separate official lectures are expressly distinguished from the embedded video and from Kamoonpuri's own claims.

## Abstract: The burden of proof has been misplaced

That fabricators infiltrated early Imāmī transmission is a fact the tradition itself records. Nobody needs to deny it to defend rigorous Imāmī ḥadīth scholarship. The real dispute concerns what that evidence proves. In “How reliable is our Hadith Corpus?”, Al-Islaah moves from the undeniable existence of forged narrations to claims about the provenance of the *four hundred uṣūl*, the alleged failure of classical compilers, the status of *al-Kāfī*, the proportion of invented material in *Biḥār al-Anwār*, and the authenticity of narrations associated with *ghuluw*. These propositions are related; they are not interchangeable.[^1]

The article’s most serious defect is an **unsupported extension from particular evidence to a population-wide conclusion**. An interpolator can alter a book without altering every copy. A flawed chain can make a report unusable without proving its text invented. A compiler can transmit a problematic account without endorsing every apparent proposition it contains. And a modern scholar’s rejection of an extraordinary narration does not establish the reliability or unreliability of thousands of others. Each transition requires evidence; rhetoric does not supply it.

We reject the opposite extreme as well. Formal reliability of a narrator does not automatically establish the integrity of every written exemplar behind him. Nor is every report in *al-Kāfī*, or any other compilation, vindicated by the compiler's reputation. Our thesis is **the necessity of discriminating verification, not unconditional authenticity**. But Al-Islaah has not demonstrated the sweeping historical conclusions it draws from its evidence. That is what this rebuttal tests.

### The propositions at issue

| Al-Islaah's proposition | What the evidence establishes | Our finding |
|---|---|---|
| Extremists inserted reports into companions' books | Supported by the Yūnus narration, which many later jurists accept | **Conceded; a serious historical problem** |
| Later books were therefore extensively copied from corrupted exemplars | A transmission hypothesis requiring identified exemplars and literary routes | **Not established generally** |
| Classical compilers made matters worse and lacked adequate scrutiny | Some questionable material survives; early exclusion and selection are also documented | **The categorical accusation fails** |
| Most of *Biḥār* is positively fabricated | Scholarly criticism, including a claim that most reports lack probative isnāds | **Majority fabrication has not been demonstrated** |
| Every unusual report about the Imams is *ghuluw* | Actual *ghuluw* must be defined doctrinally | **False as a general identification** |
| Qurʾānic comparison means every genuine report needs a directly matching verse | The report itself permits corroboration by earlier ḥadīth; Imāmī uṣūl distinguishes contradiction from specification | **Overly narrow interpretation** |
| Particular disturbing reports appear in *al-Kāfī* | Several genuinely do, some with favourable historical assessments | **Conceded, requiring individual examination** |

The following eight parts confront each charge in its strongest form, then state the precise evidentiary result.

---

## Part I. What Al-Islaah actually alleges—and why its formulation matters

### 1. Separate al-Ḥaydarī, his sources and Al-Islaah's editorial inferences

Al-Islaah introduces a video of Sayyid Kamāl al-Ḥaydarī and asserts that the early companions' books were contaminated by al-Mughīrah b. Saʿīd, Abū al-Khaṭṭāb and their associates. It then says that material entered *al-Kāfī* and *Biḥār* “without proper and rigorous scrutiny”, that the early compilers aggravated the problem by relying on dubious books, and that a majority of *Biḥār* consists of outright fabrications. These are claims made in **the article's narration of the video**, not automatically a verbatim transcript of every statement al-Ḥaydarī made.[^1]

It matters that the author supplies specific citations for the Yūnus report but supplies neither a comprehensive catalogue of corrupted *uṣūl* nor an independently reproducible census of *Biḥār*. A source can prove a narrow fact and be inadequate for a much larger conclusion. For example, if a contemporary scholar reports that many books were vulnerable to manipulation, this does not identify the source of every report that reached al-Kulaynī two centuries earlier. A defensible historical proposition must state which books, which chains, which copies, what dating, and which textual variants establish the asserted dependency.

Further, the 2016 official Arabic transcript of al-Ḥaydarī's lecture **expressly differentiates “many” from “most”**. He denies a wholesale rejection of transmitted heritage and insists on criteria beyond bare chain scrutiny. He says, in part, **كثير، لا، ليس أكثر**—many, not most—in correction of a statement attributed to him. That does not disprove Al-Islaah's separate assertion about *Biḥār*. It does prevent a fair reader from presenting al-Ḥaydarī as though he had offered a demonstrated numerical finding that most of *all* Imāmī ḥadīth was forged.[^2]

**Our charge:** the article merges a verified warning about fabrication, a modern scholar’s methodological programme, and the author's wider indictments of classical compilations without demonstrating that all three carry the same evidentiary force. A rebuttal should not deny the first; it must demand proof of the last.

### 2. The missing distinctions

A report may be *ṣaḥīḥ* or *muwaththaq* under one technical system, weak under another, historically plausible but formally mursal, or supported in meaning by converging attestations despite an uncertain individual isnād. None of these statuses is simply identical to “forged” (*mawḍūʿ*). Conversely, a formally sound chain cannot absolutely exclude textual manipulation, *taṣḥīf*, faulty paraphrase or an inaccurate source-book attribution. These are not apologetic distinctions: they determine what the evidence can logically establish.[^20][^21]

Al-Islaah is entitled to contend that a large proportion of material is not **probative** on some strict criteria. If it contends instead that a majority has been **positively invented**, it must show how non-probativity becomes demonstrated forgery, and how its proportion is calculated. A mass of weak chains is not by itself a mass of proven deliberate inventions.

---

## Part II. The Yūnus narration: a warning against fabrication, not a statistical verdict on the corpus

### 3. We accept the difficult evidence

The testimony reported by Yūnus b. ʿAbd al-Raḥmān in al-Ṭūsī's recension of al-Kashshī (*Ikhtiyār Maʿrifat al-Rijāl*, report 401) is exceptionally significant. Its path is presented through Muḥammad b. Qūlawayh and al-Ḥusayn b. al-Ḥasan b. Bundār, from Saʿd b. ʿAbd Allāh, from Muḥammad b. ʿĪsā b. ʿUbayd, from Yūnus. Within the report, Yūnus describes presenting books and transmissions acquired in Iraq to Imam al-Riḍā, who disavowed numerous reports attributed to Imam al-Ṣādiq. It also relates al-Mughīrah's insertion of reports into the books of companions of Imam al-Bāqir, and accuses Abū al-Khaṭṭāb and his circle of fabrication.[^3][^4]

The transmission should not be cheaply dismissed because of the well-known controversy about Muḥammad b. ʿĪsā b. ʿUbayd's narrations from Yūnus. Al-Najāshī preserves Ibn al-Walīd's exclusions in another context and Ibn Nūḥ's important disagreement. Sayyid Muḥammad Saʿīd al-Ḥakīm describes the relevant Kashshī line as sound through Muḥammad b. ʿĪsā from Yūnus. The detailed *rijāl* debate deserves independent treatment, but we can grant the report as historically weighty for purposes of argument.[^5][^6]

This concession strengthens the rebuttal: **the event of interpolation is not the issue being evaded**. It is the extent and later survival of the interpolation that Al-Islaah has not reconstructed.

### 4. What the narration actually says

The report includes the following criterion:

> **لَا تَقْبَلُوا عَلَيْنَا حَدِيثاً إِلَّا مَا وَافَقَ الْقُرْآنَ وَالسُّنَّةَ أَوْ تَجِدُونَ مَعَهُ شَاهِداً مِنْ أَحَادِيثِنَا الْمُتَقَدِّمَةِ**
>
> “Do not accept a report attributed to us unless it accords with the Qurʾān and Sunnah, or you find with it a corroborating witness among our earlier narrations.”[^3]

The connective **أو** (“or”) and the reference to **أحاديثنا المتقدمة** (our earlier reports) are part of the text. A programme that reduces this to a demand for an explicit Qurʾānic verse matching the precise content of every narration fails to account for the full wording. The report itself invokes the earlier narrated Sunnah as a comparator. A second, later part directs the rejection of material **خلاف القرآن** (contrary to the Qurʾān). Contradiction and absence of an express verse are different relations.

This observation does **not** mean any report can be authenticated simply by finding one equally dubious parallel. “Earlier report” cannot become a circular licence to corroborate one invention with another. Independence, chronology and provenance matter. But it is equally impermissible to amputate the witness clause and represent the narration as if it abolished non-Qurʾānic details in transmitted teaching.

### 5. From “many rejected” to “most later reports forged”: a non sequitur

Yūnus's report says that many (*aḥādīth kathīrah*) of the material he brought were denied by the Imam. The quantifier has no specified denominator in the surviving passage. We do not know from this statement alone the number of items shown, how many were declined, their exact titles, whether the rejected copies are the same exemplars used by later compilers, or which independently transmitted copies remained in circulation. The report proves the reality and gravity of the problem within the relevant collection of material; it does not yield the percentage of *al-Kāfī*, still less *Biḥār* centuries later.[^3]

Imagine three distinct histories: (a) a falsified copy was identified and avoided; (b) an altered copy was copied by one later transmitter alongside independent unaffected versions; (c) a falsified copy became the common ancestor of all known later witnesses. The warning report is compatible with each. Yet their implications for later authentication are radically different. The critic must demonstrate the relevant history for the books actually relied upon. Asserting (c) because (c) is possible is an inference without evidence.

Nor does this transfer the entire burden to the sceptic. Anyone using a report as authoritative still needs adequate reasons for its attribution. But there is a decisive difference between **not affirming a report's authority** and **affirming that it was fabricated**. A cautious jurist can withhold legal reliance without publishing a historical accusation of forgery.

### 6. Al-Ṣadr's actual discussion of *ʿilm ijmālī*

Al-Islaah invokes Sayyid Muḥammad Bāqir al-Ṣadr's argument that knowledge of insertion generates uncertainty throughout the transmitted heritage. The preserved discussions in Sayyid Kāẓim al-Ḥāʾirī's *Mabāḥith al-Uṣūl* do examine this difficulty. But they also consider the possibility that companions' books circulated in multiple copies not all accessible to a fabricator. In the discussion beginning **المخلص من هذا العلم الإجمالي** the relevant argument challenges an assumption that later compilers necessarily depended upon the altered exemplars.[^7]

This is not a demonstration that every surviving work had multiple verified pristine copies. Al-Ṣadr's discussion is an *uṣūlī* argument about the consequences of general uncertainty, not a modern census of surviving manuscripts. A critic may demand concrete evidence of textual independence in a specific case. Yet citing al-Ṣadr's worry while withholding his response converts a two-sided scholarly examination into a one-sided conclusion. It should be reported in full.

**Verdict on Part II:** the Yūnus narration justifies serious textual, isnād and provenance scrutiny. It does **not** establish the number or identities of corrupt narrations in later collections. Al-Islaah's inference needs additional demonstrations that are absent from the article.

---

## Part III. Did the early compilers disregard safeguards—or did they practise selective criticism?

### 7. The strongest argument against unqualified trust in compilers

The defender should not insist that every classical collector acted according to modern criteria or that every included report was vouched for in the same sense. *Al-Kāfī* contains weak and contested chains; its preservation of reports with troubling meanings is not a modern discovery. A preface praising sound reports is not a certificate for every item, and one compiler's judgment can be contested by another.[^10][^13]

But Al-Islaah goes beyond rejecting blanket trust. It says that later *rijālī* research revealed that the compilers did the **opposite** of filtering fabrications and **aggravated** the problem by relying on dubious books. Its footnote points to a video and promises a future exposé on weak narrators, while naming al-Burquʿī's *Kasr al-Ṣanam* as an adversarial study. These are leads for examination, not a documentary demonstration that filtering was abandoned.[^1]

To prove that a collector aggravated fabrication *rather than merely preserved historically varied reports*, one would need to establish at least: the source book and copy he consulted, a recoverable prior judgment or warning he ignored, an independent reason to consider the material forged, the scope of the error and an appropriate counterfactual. Displaying the presence of some weak narrators does not prove deliberate or uncritical authentication of every report through those narrators.

### 8. Ibn al-Walīd and *Nawādir al-Ḥikmah*: a documented counterexample

Al-Najāshī's entry for Muḥammad b. Aḥmad b. Yaḥyā identifies him as trustworthy in transmission while recording complaints that he also narrated from weak transmitters and in disconnected forms. Ibn al-Walīd famously excluded named routes from *Nawādir al-Ḥikmah*. Al-Ṣadūq followed many of these exclusions. Ibn Nūḥ challenged at least one disputed exclusion involving Muḥammad b. ʿĪsā b. ʿUbayd.[^9]

The documentation matters for three reasons. **First**, early critics knew that a respected author could preserve unreliable material. **Second**, they distinguished between a book and particular routes within it; they did not simply accept all or discard all. **Third**, their internal disagreements show genuine evaluation, not an invariant apologetic rule designed to guarantee a favoured conclusion.

We cannot infer from this one example that every book underwent such scrutiny or that Ibn al-Walīd's choices were always sound. But one documented case is sufficient to refute a literal assertion that the early Imāmī scholarly milieu had no practical means of distinguishing suspect transmissions. The historical claim must be restricted: some safeguards existed; their **coverage and success** have to be investigated book by book.

### 9. Al-Kulaynī: aspiration, criteria and the actual text of *al-Kāfī*

In the introduction to *al-Kāfī*, al-Kulaynī recounts a request for a collection permitting religious knowledge and practice through sound reports. His preface acknowledges divergent narrations and points to criteria for distinguishing them. The wording warrants care: the requester's aspiration and the compiler's stated project are not automatically a formally quantified guarantee that every preserved report is authentic under later technical *rijāl*.[^10]

Nevertheless, the preface and the collection's own chapter on taking the Sunnah with Qurʾānic witnesses contradict the assertion that these criteria were simply unknown or inherently ignored. The relevant *al-Kāfī* chapter transmits reports on rejection of material contrary to the Book. Al-Islaah is entitled to argue that the compiler's implementation was inconsistent; it must demonstrate that case specifically, rather than infer ignorance from the mere existence of contested narrations.[^11]

A crucial difference must also be maintained between **collecting** for scholarly assessment, **transmitting** an inherited source, **including** a text in a thematic chapter and **judging** that its content is established. Not all genres or compilers make the same claims about these operations. If Al-Islaah wishes to hold al-Kulaynī responsible for a particular transmitted statement, the argument must identify which of these claims it attributes to him and why.

### 10. Al-Ṣadūq: a more explicit claim—and a real standard for testing him

Al-Ṣadūq's preface to *Man Lā Yaḥḍuruhu al-Faqīh* is more explicit: **بَلْ قَصَدْتُ إِلَى إِيرَادِ مَا أُفْتِي بِهِ وَأَحْكُمُ بِصِحَّتِهِ**—he intended to include reports he used for legal judgment and considered sound.[^12] That is significant evidence of selection; it does not force every later scholar to accept his assessments. Al-Khūʾī's rejection of an automatic universal authentication of the Four Books supplies precisely that important distinction.[^13]

Al-Islaah could challenge a selected item in *al-Faqīh* by identifying its underlying source, transmission defects and meaning. Such evidence could undermine al-Ṣadūq's particular judgment. But an accusation that he did not try to select reports is incompatible with his stated project and the documented Qummī tradition of exclusions. One may criticise the **results** of a selection method without pretending the **method did not exist**.

### 11. The tradition has never been one uniform school

Al-Murtaḍā's scepticism about certain isolated reports, al-Ṭūsī's defence of acting upon properly transmitted reports under stated conditions, al-Ḥurr al-ʿĀmilī's stronger defence of transmitted compilations, and al-Khūʾī's critical rejection of universal authenticity are substantive historical differences. They cannot all be collapsed into a single “classical position”.[^14][^15][^16][^13]

Yūsuf al-Baḥrānī’s *al-Ḥadāʾiq* defends older methods of recognizing authoritative transmission while criticising the later technical fourfold grading. Muḥaddith al-Nūrī’s *Mustadrak* takes a further documentary path by recovering reports from neglected sources and discussing the provenance of their books in its *Khātimah*. Their methods deserve assessment on their own terms, rather than being classified in advance as universal acceptance or universal rejection. Neither later recovery of a book nor traditional confidence in a source discharges the need for critical investigation of a particular report.[^25][^26]

The variety of these methods is an argument **against** claiming an infallible corpus. It is also an argument **against** depicting Imāmī scholarship as a long, unexamined process of indiscriminate repetition. Several centuries of disagreement over the authority of reports is not the absence of criticism; it is one of the principal forms criticism has taken.

**Verdict on Part III:** Al-Islaah has a legitimate case for criticizing particular transmissions and inadequate safeguards in particular circumstances. It has not established its categorical portrait of early compilers as having done the opposite of scrutiny. Documentary cases of early exclusions rebut that generalization without vindicating everything those compilers preserved.

---
## Part IV. The “four hundred uṣūl”: a historical archive, not one common corrupted manuscript

### 12. Why the label *al-uṣūl al-arbaʿumiʾah* cannot bear the entire argument

Al-Islaah's historical picture is intuitively powerful: the Imams' students preserved their words in notebooks; fabricators contaminated the notebooks; later compilers derived their collections from those books; therefore the collections are compromised. The middle stages, however, require historical proof. The expression *al-uṣūl al-arbaʿumiʾah* is a traditional designation for a body of early recorded transmission, not a single manuscript with one editor, one copying history or one uniformly documented point of access. There are distinct authors, titles, routes, times and recensions.[^8]

A rigorous *fihristī* investigation does not merely ask whether a report goes through narrators each judged *thiqa*. It asks whether the book attributed to the named author circulated by a particular route; whether the form reaching a later compiler can be distinguished from rival recensions; whether independent quotations survive; whether textual agreements imply genuine independence or copying from a shared ancestor; and whether a disputed reading is original, accidental or deliberate. This is precisely the type of inquiry made necessary by the Yūnus report. One cannot condemn it as irrelevant and simultaneously assert that compromised source-books determine the fate of the entire corpus.

Al-Najāshī's directory and al-Ṭūsī's *Fihrist* supply titles and literary transmission routes, but neither is a complete modern catalogue of surviving archetypes. Nor does a named route automatically establish that the exact extant text of an attributed *aṣl* is intact. Early book transmission is an evidentiary field, not a slogan favouring either side.[^8][^43]

### 13. Worked example: Zayd al-Narsī demonstrates both possibility and discrimination

Al-Najāshī describes Zayd al-Narsī as possessing a book transmitted by a group and supplies a named literary route ending with Ibn Abī ʿUmayr and Zayd. In another witness, al-Ṭūsī's *Fihrist*, the origin of the works attributed to Zayd al-Narsī and Zayd al-Zarrād is disputed: al-Ṣadūq reports that Ibn al-Walīd regarded the attribution as forged and linked its production to Muḥammad b. Mūsā al-Hamdānī, while the same discussion notes Ibn Abī ʿUmayr's transmission of the book.[^42][^43]

This dispute is awkward for an unconditional traditionalist. There is plainly a controversy about a purported early source; the presence of a name in a catalogue cannot extinguish it. But the same dispute is also awkward for a sweeping sceptical story: later Imāmī sources do preserve **specific allegations, routes and counterarguments**, not mere unexamined reliance on a block of four hundred books. Muḥaddith al-Nūrī's defence in *Khātimat al-Mustadrak* is a later attempt to adjudicate provenance, not proof by itself that the extant book is autograph or wholly unchanged.[^44]

The appropriate conclusion is graded. The medieval existence of an attribution is supported. A literary route is documented. The identification of every modern witness with the original book is a further question. Its individual reports must still be assessed. **This is what an actual book-provenance argument looks like**. Al-Islaah cannot substitute the general possibility of insertion for these steps when asserting the fate of the corpus as a whole.

### 14. Corroboration requires independent genealogy

An identical passage appearing in *al-Kāfī*, *Tahdhīb* and *Wasāʾil* is not necessarily three witnesses: the latter may reproduce an earlier book, and another collection may share a common predecessor. Conversely, two differently routed early book traditions may offer meaningful corroboration even where later printings agree. Source criticism therefore has to proceed backward from the compendium to the earliest identifiable witness and branch point. A credible critical edition must mark shared ancestry; counting occurrences in later encyclopaedias as independent attestations would inflate the evidence.

That caution applies equally to sceptical reconstruction. Finding one compromised book does not show that each surviving copy of a differently transmitted work came from it. The soundest position is an evidentiary middle: **neither serial duplication nor serial contamination may be assumed without mapping the chain of dependence**. Al-Burūjerdī's *Jāmiʿ Aḥādīth al-Shīʿa* was designed partly to help jurists compare parallel narrations and suspected textual or isnād variants. Its value is documentary organisation; it does not magically authenticate every report it gathers.[^27]

**Verdict on Part IV:** the historical possibility of corrupted *uṣūl* is well grounded. The assertion that the surviving Imāmī corpus descends, to the claimed degree, from those particular corrupt copies is not demonstrated by Al-Islaah's broad account. An objector needs identified books and witnesses, not simply the number four hundred.

---

## Part V. Is most of *Biḥār al-Anwār* fabricated? Testing the strongest numerical accusation

### 15. Three claims Al-Islaah treats as one

The article asserts that a **majority of narrations in *Biḥār al-Anwār* are outright fabrications**. Its footnote cites the Persian scholar Jalāl al-Dīn Āshtīyānī on baseless reports in *Biḥār*, particularly materials of *manāqib*, and directs readers to al-Ḥaydarī's explanation of that quotation. These are serious references, but their argumentative scope must be examined rather than assumed.[^1]

Consider three distinct statements: (i) a large volume contains abundant ungrounded accounts; (ii) many or most reports do not satisfy a particular chain-based test for legal proof; (iii) more than half of the reports are demonstrably products of deliberate invention. A scholar might accept (i), and even (ii), without claiming (iii). *Ghayr muʿtabar*, *lā aṣl lahu*, *ḍaʿīf*, *mursal* and *mawḍūʿ* are not synonyms. To infer (iii), the critic needs either compelling independent textual grounds or an explicit demonstration of fabrication for a defined majority.

### 16. Āshtīyānī's Persian quotation: powerful warning, insufficient denominator

Al-Islaah reproduces Āshtīyānī's assessment that *Biḥār* is full of reports without basis, with especially many forged reports in its *manāqib* material. He recommends an initial presumption against accepting the reliability of such reports because of the frequency of inventions in that genre. This is a serious negative assessment; it should not be dismissed because it is inconvenient. Yet its subject is **especially the manāqib domain**, and it offers no report-by-report tally demonstrating that more than half of the contents of the complete encyclopaedia were deliberately invented.[^1]

Al-Ḥaydarī's official 2016 transcript quotes and discusses this Persian passage. Importantly, he explicitly indicates he is reporting Āshtīyānī's position rather than necessarily adopting each formulation as his own. In a separate official 2018 lecture, al-Ḥaydarī reports that Āshtīyānī connected certain methodological concerns with recollections of al-Burūjerdī—particularly reports praising or condemning places and accounts concerning foods. Those recollections are relevant historical testimony, **not a published census of the entirety of *Biḥār*** or proof that al-Burūjerdī personally authored every broad characterization later made in his name.[^2][^50]

If the claim is that Āshtīyānī had a skeptical default for *manāqib*, cite him. If the claim is that a majority of *Biḥār* is established as *mawḍūʿ*, present the underlying audit and its denominator. One should not silently convert a genre-sensitive warning or a recollection of an oral remark into an arithmetical conclusion about hundreds of thousands of transmitted items and parallel reports.

### 17. Al-Muḥsinī's harder evidence—and the crucial distinction

Shaykh Muḥammad Āṣif al-Muḥsinī remarks in his introduction to *Mashraʿat Biḥār al-Anwār* that most reports extracted into *Biḥār* are not *muʿtabar* **by their isnāds** under the method at issue. The statement is significant because it comes from a scholar who undertook selective work on the collection itself. A response that hides this evidence is not credible.[^20]

Yet al-Muḥsinī does not thereby demonstrate that each such text is an invention. In the same methodological discussion he distinguishes insufficiency of chain evidence from the historical conclusion that the text was fabricated, while allowing that convergence and circumstances can sometimes supply confidence despite an inadequate standalone chain. This distinction is central to a responsible critique.[^20][^21]

A bare isnād-only count also understates the bibliographical structure of an encyclopaedia. *Biḥār* was intended to gather earlier materials, including poorly sourced or rarely available texts; it was not designed as a new compilation of only reports meeting a single modern criterion. Simply adding a paragraph preserved from a source book does not amount to the author's declaration that its chain is sound. The proper evaluation is a source-critical one: identify what *Biḥār* reproduces, whether the source survives independently, its textual variants and its evidentiary status.

### 18. What would settle the numerical question?

Al-Islaah could establish a meaningful rate only after declaring a **unit of analysis**. Is it counting every numbered item, each unique report, each distinct proposition, every source-text excerpt, or every independently attested literary tradition? A single passage repeated in several volumes creates multiple entries but need not create multiple independent inventions. A four-chain parallel can be four numbered reports but one underlying account. Any percentage without deduplication and explicit classification rules can mislead.

A reproducible study would sample or classify a clearly defined corpus, record edition boundaries, separate unknown attribution from positive fabrication, report disputed judgments, and allow independent rechecking. It would also distinguish genre: unusual *manāqib*, devotional prayers, legal rulings and historical anecdotes may have very different transmission profiles. Until such work is supplied, **“most fabricated” remains a contested polemical assertion, not a demonstrated statistical result**.

**Verdict on Part V:** many reports in *Biḥār* are indeed weak, unverified or contested. Scholarly concern is real. The evidence Al-Islaah cites does not establish its more expansive numerical assertion that a majority of the entire compilation are positively forged. Equally, our rebuttal does **not** claim that a majority are authentic; that would require its own independent audit.

---

## Part VI. The Qurʾānic criterion and *ghuluw*: the two interpretive controversies

### 19. Compatibility with the Qurʾān is not identical to explicit duplication of verses

Al-Islaah rightly insists that the Imams could not teach something genuinely incompatible with the Qurʾān and firmly established Sunnah. We agree. But it also states that no report should be accepted unless there is Qurʾānic and Sunnah “confirmation” for its content. What counts as confirmation? If it means no contradiction of definitive scripture, with additional evidence for attribution, it is broadly compatible with established Imāmī critical approaches. If it means that a narration must have an identical or plainly explicit Qurʾānic proposition, the cited Yūnus narration does not warrant so restrictive an interpretation.[^3][^11]

An authenticated report about a particular application of prayer, ritual purity, inheritance or trade need not repeat an explicit Qurʾānic sentence in order to function as an explanation of general instruction. Imāmī *uṣūl* distinguishes **contradiction** (*tabāyun*) from **specification** (*takhṣīṣ*) and **qualification** (*taqyīd*). A single report purporting to abolish a definitive Qurʾānic principle poses one problem; a report providing a condition or exception to a broad general rule poses another. Al-Ṣadr's recorded treatment of the Qurʾānic *ʿarḍ* reports examines these differences rather than treating every added detail as automatically contradictory.[^19]

Sayyid ʿAlī al-Sīstānī, in a discussion of *Lā Ḍarar*, speaks of an underlying conformity or opposition to the Qurʾān and established Sunnah detected through internal and external indications. This is not a licence to authenticate words merely because they sound edifying. It is an approach requiring actual interpretative and contextual argument, not simply a keyword match.[^17]

There is also a methodological circularity to avoid. If a preferred report determines an interpretation of scripture, and that interpretation is then used to authenticate the report, the test proves nothing independently. On the other hand, if a critic invents an artificially narrow reading of the Qurʾān and declares all further detail contradictory, that too predetermines the result. The correct criterion demands independent warrant for both the scriptural proposition and the report's attribution.

### 20. The contemporary Imāmī methodology Al-Islaah does not adequately reckon with

Al-Islaah sometimes makes rejection of weak reports appear to be a contest between inherited books and a newly discovered Qurʾānic standard. Yet the official office of al-Sīstānī lists among the central forms of juristic expertise **methods of establishing a report's attribution**, including *rijāl*, knowledge of source books, awareness of the motives for fabrication, identification of inserted materials, comparison of differing copies and separation of a transmitted matn from compiler commentary. This is a documentary and interpretative method, not automatic devotion to a book-title.[^18]

The work associated with al-Burūjerdī's *Jāmiʿ Aḥādīth al-Shīʿa* reinforces this logic through parallel presentation of sources, attention to variants and avoidance of mixing transmission with juristic annotation. These tools help identify the very problems Al-Islaah invokes. Neither jurist's approach guarantees any given narration is authentic, and different scholars apply different evidential thresholds. But the notion that rigorous examination of books, copies and content is foreign to modern mainstream Imāmī *uṣūl* is unsustainable.[^27]

### 21. *Ghuluw* cannot be defined as “whatever looks supernatural”

The historical *ghulāt* were accused of claims crossing the boundary between the Creator and His creatures, including attributing divinity or prophethood to the Imams and various forms of independent divine prerogative. Al-Ṣadūq and al-Mufīd condemn these doctrines. Al-Majlisī warns, in his own commentary at *Biḥār* 25:349, against calling a trustworthy transmitter an extremist merely because he transmits extraordinary reports—while also refusing the attribution of independent divine creative power to the Imams.[^22][^23]

The Qurʾān depicts Jesus's extraordinary acts as occurring **by God's permission** (Q 3:49) and the bringing of Bilqīs's throne through knowledge from the Book (Q 27:40). Such verses establish that extraordinary agency granted to a creature is not automatically divinity. They do not establish that every later miraculous narration about the Imams actually occurred. That remains a question of reliable attribution and interpretative context.

Al-Islaah's statement that *all reports supporting ghuluw* are invented risks becoming tautological: if “ghuluw” is defined as definitively false doctrine, then any report unambiguously asserting it would indeed fail doctrinal scrutiny. But it would be circular to **first label every contested miraculous narration ghuluw and then reject it because ghuluw is false**. The report must be interpreted on its own terms, and the doctrine must be defined independently of the desired conclusion.

### 22. What about unseen knowledge, creation and sustenance?

The expression “knowledge of the unseen” may mean intrinsic, unlimited divine omniscience; it may mean particular knowledge granted by God; or it may be a hyperbolic later attribution. These are different claims. Likewise, “creation” and *rizq* may denote independently exercised divine sovereignty, agency by God's permission, or mere metaphorical terminology. Correct Imāmī *tawḥīd* excludes independent divine prerogatives in any created being. But asserting that exclusion does not itself identify the original sense or historical attribution of every disputed passage. Exact wording, theological explanation and chain assessment remain decisive.[^22][^23][^24]

A valid *matn*-based challenge must therefore have the form: **this report, under its most plausible contextual reading, asserts this precisely defined prohibited doctrine; that doctrine contradicts demonstrably definitive evidence; here is why alternative readings fail**. An invalid challenge simply says that the report sounds exaggerated to a modern reader. A similarly invalid defence supplies a speculative nonliteral reinterpretation for any bizarre text without evidence that a contemporary audience could have understood it that way.

**Verdict on Part VI:** Qurʾānic evaluation and rejection of actual *ghuluw* are genuine Imāmī principles. Al-Islaah is not entitled to substitute a simplistic verse-matching rule for rigorous *uṣūlī* interpretation, nor to convert every extraordinary claim into evidence of doctrinal extremism. The burden of authenticating any particular miracle claim remains on its advocate.

---
## Part VII. Al-Islaah's exhibits examined: what each narration actually proves

### 23. Why individual case studies are not merely an apologetic distraction

Al-Islaah lists reports concerning the number of Qurʾānic verses, racial and ethnic hierarchy, illegitimate birth, Fāṭimah's reaction to her pregnancy with al-Ḥusayn, a cosmic whale and bull, and an elephant allegedly transformed from a man. A properly adversarial rebuttal must not just appeal to the moral standing of al-Kulaynī. It must identify each text, present its difficult content, distinguish the alleged original meaning from its chain's status and ask what follows for the broad allegations.[^1][^28]

Five outcomes are possible in a given case: (1) the accusation misquotes or distorts the source; (2) the source is correctly quoted but its chain is materially deficient; (3) the chain receives a favourable traditional grade but the content creates serious historical, empirical or theological difficulties; (4) a contextual or variant reading changes the asserted proposition; or (5) the content is correctly represented and remains genuinely unresolved. **One cannot decree outcome (1) merely because the content is embarrassing, nor outcome (3) merely because a critic finds it offensive.** The whole purpose of critical work is to decide which result is warranted by the evidence.

### 24. Case A — Seventeen thousand Qurʾānic verses

In *al-Kāfī* 2:634, an entry in a *nawādir* setting reads, in part:

> **إِنَّ الْقُرْآنَ الَّذِي جَاءَ بِهِ جَبْرَئِيلُ ... سَبْعَةَ عَشَرَ أَلْفَ آيَةٍ**
>
> “The Qurʾān brought by Gabriel ... [comprised] seventeen thousand verses.”[^29]

This is not an invented criticism: the text is there. The printed entry begins with ʿAlī b. al-Ḥakam → Hishām b. Sālim → Imam al-Ṣādiq, without a fresh explicit complete path from al-Kulaynī at that point. It is methodologically incorrect to declare the displayed isnād self-sufficient without reconstructing its preceding context. Editions also record a reading **Hārūn b. Muslim** in place of **Hishām b. Sālim**; some witnesses and discussions refer to **seven thousand**, not seventeen thousand. The latter variant is attested but cannot presently be proved the original merely by preference.[^29][^31]

There is a more difficult fact to concede: al-Majlisī discusses the report in *Mirʾāt al-ʿUqūl*, grades it *muwaththaq* on one reading and considers a more favourable classification with another reading. He also advances interpretative positions about Qurʾānic alteration that should not be concealed or falsely imputed to all Imāmī scholars.[^30]

But the validity of the Qurʾān now publicly transmitted rests on forms of evidence exceeding the face-value claim of one disputed report. Al-Ṣadūq explicitly affirms the integrity of the received Qurʾān in *al-Iʿtiqādāt*; al-Ḥurr al-ʿĀmilī discusses this narration in his treatise on the Qurʾān's transmission; and al-Khūʾī devotes a major examination in *al-Bayān* to defending its preservation. They do not all employ identical reasoning, but none can be legitimately represented as having simply accepted this narration's apparent arithmetic as established orthodoxy.[^32][^33][^34]

**Finding:** Al-Islaah is right that the printed collection contains a difficult text, and al-Majlisī's favourable technical judgment is a genuine challenge to a simplistic chain-only approach. It is wrong to infer from this that Imāmī doctrine is defined by the report, that all scholars authenticated its apparent meaning, or that the presence of this single item quantifies the reliability of the collection. The priority is a textual and provenance audit, not concealment.

### 25. Case B — The earth resting on a whale and bull

*Rawḍat al-Kāfī* 8:113, report 55, transmits Abān b. Taghlib's dialogue about the earth resting upon a whale, then water, rock, the horn of a bull and further elements. The chain as displayed begins **Muḥammad → Aḥmad → Ibn Maḥbūb → Jamīl b. Ṣāliḥ → Abān**. These first two names are abbreviated and require identification through the collection's context. In the modern Thaqalayn grading index al-Majlisī's verdict is displayed as **ṣaḥīḥ**, with a reference to *Mirʾāt* 15:201; a separately digitised edition employs different volume numbering, so the edition-level reference must be kept distinct.[^35][^36]

A defender who asserts that every empirically impossible narration must be obviously weak has a difficult counterexample here. We must concede that a favourable traditional chain assessment has been transmitted. There are also proposed explanations. Sayyid Muḥammad Ṣādiq al-Rūḥānī offers the possibility that *ḥūt* and *thawr* denote astronomical signs rather than living animals; but that interpretative possibility does not prove how every part of the passage would have been understood by its earliest recipients.[^38]

Nor is the presence of another route in *Biḥār* straightforwardly independent evidence if the routes converge through Ibn Maḥbūb. Genealogical analysis of the common source remains necessary.[^37]

If the report asserts that the physical earth literally rests on a whale and bull, that apparent cosmology conflicts with established empirical knowledge. A conscientious scholar may decline the literal sense or withhold attribution despite a favourable chain grade. **There is no scholarly obligation to force a false cosmology into accepted doctrine because a grading index says ṣaḥīḥ.** Equally, the failure of this report to establish its apparent cosmology would not render unrelated legal reports fictitious.

**Finding:** the critic has identified a real problem. It is a serious challenge to simplistic universal acceptance and an occasion for source criticism—not evidence that *most* reports are fabricated. Our response is expressly limited: we do not claim to have established a convincing original nonliteral meaning.

### 26. Case C — An elephant as a transformed adulterous king

*Al-Kāfī* 6:246, report 14, contains:

> **الْفِيلُ مَسْخٌ كَانَ مَلِكًا زَنَّاءً**
>
> “The elephant is a transformed being; [it] was an adulterous king.”[^39]

The displayed path is Muḥammad b. Yaḥyā → Aḥmad b. Muḥammad → Muḥammad b. al-Ḥasan al-Ashʿarī → Imam al-Riḍā. The modern grading index reports al-Majlisī's assessment in *Mirʾāt* 22:35 as **majhūl**. That is a specific adverse assessment, not proof that each narrator deliberately lied. But it is enough to make it incorrect to assert that al-Majlisī straightforwardly authenticated this report by chain.[^40]

There is a second problem in Al-Islaah's own description: it uses the language of **reincarnation**. A claim of *maskh*—a punitive transformation of a particular person—is not automatically the doctrine of *tanāsukh*, successive transmigration of a soul into another body. Whether either report is authentic is a separate question. Nor does the narrative necessarily entail that extant elephant species descended from transformed humans. Al-Ṣadūq transmits another account that transformed persons did not leave offspring, although the chain of that additional account has **not been independently authenticated here**.[^41]

The more exact reading is neither that this account is vindicated by semantic ingenuity nor that it proves a biological theory of modern elephants. Its alleged attribution remains open to criticism. The burden lies with anyone treating it as historical fact.

**Finding:** a troubling text exists; a classical grading offers grounds for caution; the assertion that it represents “reincarnation” introduces a conceptual confusion; and no inference about most of the ḥadīth corpus follows.

### 27. Case D — Fāṭimah and the pregnancy with al-Ḥusayn: a materially distorted summary

This example allows a considerably firmer textual rebuttal. Al-Islaah alleges that there is a claim that Fāṭimah **hated Imam al-Ḥusayn from the moment she conceived him** because she had been informed of his future killing.[^1]

The actual *al-Kāfī* report, book of the proof, chapter on al-Ḥusayn's birth, report 3, describes Fāṭimah's distress at pregnancy and childbirth following the news that her son would be killed. It then supplies its own explanation:

> **وَلَكِنَّهَا كَرِهَتْهُ لِمَا عَلِمَتْ أَنَّهُ سَيُقْتَلُ**
>
> “But she was distressed by it because she knew he would be killed.”[^48]

In the narrative's own logic, this is grief at the fate awaiting a dearly loved child, not hostility towards that child's person, character or sanctity. Rendering it simply as “Fāṭimah hated al-Ḥusayn” without the immediately accompanying causal explanation changes the reader's understanding of the passage. The distinction is substantial even if the reader ultimately rejects the narration's attribution. The relevant grading index lists the report as **mukhtalaf fīh** in connection with al-Majlisī rather than producing an uncontested modern authentication; al-Behbūdī did not include it in his abridged *Ṣaḥīḥ al-Kāfī*.[^51]

A careful commentator may also question the report's application of Qurʾān 46:15 and the historical mechanics of the pregnancy story. Those are legitimate separate issues. But a polemic must first report the words and the reason the text itself supplies. **Here the original objection does not fairly preserve the relevant context.**

**Finding:** the report exists, but Al-Islaah's emotive summary is misleading. It turns sorrow concerning the foretold killing into a simpler charge of hatred. The corrected reading does not independently authenticate the narration, but it removes the asserted scandal in the form presented.

### 28. Case E — Racially disparaging reports: we must not conceal the evidence

Al-Islaah alleges that some narrations express racial inferiority concerning certain non-Arab and non-Persian ethnicities. This cannot responsibly be dismissed without inspecting the corpus. An identifiable example is *al-Kāfī*, vol. 5, book of marriage, chapter on marriage with Kurds and Sudan, report 1. The wording discourages marriage with **al-Zanj** and uses explicitly derogatory language. The modern grading index records al-Majlisī's judgment as **ṣaḥīḥ ʿalā al-ẓāhir**, while noting that al-Behbūdī did **not** include the report in *Ṣaḥīḥ al-Kāfī*. The same chapter's second report is marked *mursal* and its third *ḍaʿīf ʿalā al-mashhūr* in the displayed grading index.[^49]

One should not pretend that the first report is an obviously weak-chain fabrication merely because its content is morally disturbing. Nor does the technical phrase *ṣaḥīḥ ʿalā al-ẓāhir* establish that its racial judgement is a definitive Imāmī doctrine. In addition to narrator assessments, the documented difference between **Masʿadah b. Ziyād** and **Masʿadah b. Ṣadaqah** in some witnesses needs investigation. Any attempt to treat the text as binding teaching should also address the Qurʾānic standard that human worth is not established by ethnicity but by *taqwā* (Q 49:13), and the contextual demands of a real attribution analysis.[^49]

The proper response is **not** a glib harmonisation that implicitly endorses racial denigration. It is to state plainly that the transmitted passage is offensive on its face, that its source and variant transmission require serious examination, and that even a formal chain grading does not settle its normative authority. The evidence of a troubling narration is real; a numerical claim about the whole corpus still does not follow.

**Finding:** Al-Islaah is justified in drawing attention to this class of narrations. Our objection concerns its failure to undertake the further work needed to establish authorship, doctrinal status and corpus-level prevalence—not the proposition that there is nothing concerning here.

### 29. Case F — “Every non-Shīʿī is of illegitimate birth”: the exact report has not been established by Al-Islaah's summary

The article alleges a sweeping statement about the illegitimate birth of all non-Shīʿīs but does not, in this particular essay, provide a specific numbered *al-Kāfī* report with full Arabic wording, chain, variant and edition. There are polemical statements involving *walad zinā* in different sectarian texts and there are legal discussions of illegitimate birth, but they are not automatically the **same proposition**. A narration describing opponents in a particular conflict, a legal narration about testimony, and an assertion of the biological illegitimacy of every person outside a school are distinct claims.[^1]

We cannot responsibly invent a chain, grade or original context merely to provide a convenient answer. Here the evidentiary criticism is procedural but substantial. Al-Islaah should identify the exact wording it regards as dispositive. The meaning of terms, scope of alleged universals, direct chain, earliest witness and the difference between invective and literal genealogy would then be examined. It is not scholarly to defend a report we cannot precisely identify; it is equally unsound to take an inflammatory paraphrase as sufficient proof of a particular authenticated doctrine.

**Finding:** this specific accusation remains **unadjudicated** pending an exact primary-source identification. That is a limit of the present rebuttal, not a declaration that no such reprehensible report could exist.

### 30. Summary of the exhibits

| Exhibit | Source located? | Specific outcome | Relevance to a corpus-wide thesis |
|---|---|---|---|
| Seventeen thousand verses | Yes | Real difficult text, disputed variants and contested scholarly interpretation | Cannot generate a percentage |
| Whale and bull | Yes | Apparent cosmology conflicts with science; favourable historical grading reported | Refutes naïve chain-only certainty, not unrelated reports |
| Elephant transformation | Yes | Historical report graded *majhūl* by al-Majlisī in index | Not proof of modern-species descent or *tanāsukh* |
| Fāṭimah and al-Ḥusayn | Yes | Al-Islaah's “hatred” summary obscures the narration's stated grief over his death | Demonstrates importance of full-text reading |
| Ethnic disparagement | Yes, a relevant chapter | At least one text has favourable reported grading and serious ethical difficulties | Requires source and normative criticism, no blanket dismissal |
| Universal illegitimate birth claim | Not precisely identified by the article's citation | Exact wording and isnād still needed | Cannot be used as a verified specimen yet |

The table illustrates the analytical advantage of refusing both all-or-nothing instincts. A defensible response can vindicate a textual objection in one place, concede a serious problem elsewhere, and decline a sweeping inference in every case unless additional evidence supports it.

---

## Part VIII. Positive verification, the strongest objection and the final verdict

### 31. Can the defender establish any positive case—or merely avoid disproof?

The sceptic's strongest challenge is not “some reports are forged”. It is: **why should anyone affirm the attribution of a particular narration when both trustworthy narrators and their books could be deceived?** The answer cannot be “because the book is famous” or “because the report supports our doctrine”. Positive justification requires a convergence of evidence appropriate to the claim. Depending on the report, that may include a reliable and chronologically possible chain, a documented older written source, genuinely independent recensions, early attestation of the wording, compatibility with definitive knowledge, and consistency across variants. A text can be historically defensible without every element being present in every case; but whatever is claimed must be justified.[^18][^27]

Three documentary examples from the evidence reviewed clarify the kind of positive progress possible, even though they are **not** a statistical validation of the entire collection:

1. **The Yūnus testimony itself.** A named path, recoverable wording, and explicit acceptance of its probative value by later jurists demonstrate that even a challenging warning report is examined with transmission tools. It is not made historical fact merely because it is convenient to a polemic.[^3][^6]
2. **The *Nawādir al-Ḥikmah* exclusions.** Al-Najāshī preserves concrete transmitter-specific judgments and disagreement between Ibn al-Walīd and Ibn Nūḥ. This is positive evidence that an early book's contents were subject to differentiated review, although it does not prove the effectiveness of every selection made.[^9]
3. **Comparison of extant literary routes.** Al-Najāshī's and al-Ṭūsī's testimony about Zayd al-Narsī illustrates how existence, attribution, route and extant content can be argued separately. Its contested status is a reason to test each part, not a reason to give up historical investigation. The positive datum here is the *documented route and dispute*, not a completed authentication of Zayd's surviving work.[^42][^43]

Additional case-by-case studies should assess reports of legal doctrine and transmitted theological propositions through genuine, independent book witnesses and early commentary. This paper has not established a representative sample rate of reliable Imāmī reports; claiming one would repeat the numerical overreach we criticise in Al-Islaah. Our rebuttal is therefore **stronger against unwarranted generalisations than it is a completed catalogue of authenticated transmissions**. That distinction must be made explicit.

### 32. The most powerful objection to our defence

A critic can reasonably respond: “Even if you prove that Al-Islaah cannot count the forged material, the burden of establishing authenticity still falls on the person who invokes a report. A strong *rijāl* grade cannot exclude a corrupt book copy; your source catalogues are not original autographs; the surviving evidence is fragmentary.” This objection is substantial. We concede that **a report's authority cannot be rescued by disproving an exaggerated claim about the number of forgeries**. Each report offered as proof must independently satisfy the chosen standards of evidence.

But it does not follow that every item is in permanent doubt. The relevant historical and juristic debate is about how much convergence yields warranted confidence or legal probativity, and under what conditions. Imāmī scholars differ: the stance of al-Murtaḍā towards isolated reports is not the stance of al-Ṭūsī, al-Ḥurr or al-Khūʾī. A critic must identify which rule of authority is being applied. A chain's formal status, whether a text was probably uttered (*wuthūq al-ṣudūr*), and whether one may rely on it in law (*ḥujjiyyah*) are related but not identical judgments.[^14][^15][^16][^13]

A further complication is *naql bi-l-maʿnā*—transmission by meaning. *Al-Kāfī* preserves a report through Muḥammad b. Muslim allowing some difference in wording where the narrator accurately intends the meaning. Al-Muḥsinī discusses the report and notes the difficulty of determining how widespread such paraphrase was, while al-Majlisī distinguishes conditional permission from the preference for exact quotation. This demonstrates neither universal corruption nor perfect word-for-word preservation. It does explain why the stability of particular legal particles, numbers and expressions may require comparing independent versions.[^45][^46][^47]

Nor should the defender weaponise supposed corroboration. If three later sources reproduce a single earlier exemplar, their agreement may show stable copying but cannot supply three independent early attestations. A faithful *fihristī* response requires identifying the actual common source and what survives of its genealogy. This is the proper ongoing programme of research, not a claim that the entire corpus has been proven intact.

### 33. A transparent protocol for future disputed reports

Any future article in *The Imāmī Review* should require the following: original Arabic and adequate immediate context; complete bibliographic identifier and edition; explicit display and possible reconstruction of the chain; transparent *rijāl* disputes; earliest recoverable book witness; known variants and their manuscript basis; relationships among apparently parallel routes; relevant theological and Qurʾānic constraints without circularity; later scholarly judgments with edition-specific citations; and a separate statement of **(a) attribution, (b) meaning and (c) permissible legal or doctrinal use**. The reader should be able to reproduce the verdict or identify precisely where disagreement begins.[^18][^27]

Especially for charges of *ghuluw*, doctrinal content must be defined independently. For racial claims, ethically troubling texts cannot be accepted simply on their superficial chain grade. For empirically testable cosmology, external knowledge is relevant. For Qurʾānic preservation, public transmission has an evidential status different from one disputed report. For narrations said to be fabricated, **non-authentication must not be silently relabelled as proven forgery**.

### 34. Formal findings on Al-Islaah's central allegations

**Established or substantially justified:** early insertion of false reports; the danger of relying automatically on an outer chain; the existence of objectionable and technically problematic narrations in important Imāmī books; the need for Qurʾānic, textual and bibliographical scrutiny; and significant historical scholarly criticism of large compilations.[^3][^20]

**Overstated or not demonstrated in this article:** a direct blanket descent of later collections from uniformly compromised “four hundred uṣūl”; a categorical absence of early filtering by principal compilers; a count establishing that most of all *Biḥār* are positively fabricated; and the inference that unusual miracle reports necessarily teach prohibited *ghuluw*.[^8][^9][^20][^23]

**Textually misleading example:** the description of Fāṭimah as hating al-Ḥusayn without adequately representing the report's own statement that her distress concerned his foretold martyrdom.[^48]

**Unresolved:** the ultimate provenance of particular disputed *aṣl* recensions, the exact attribution and interpretation of the whale report, the manuscript history of the seventeen-thousand wording, the validity of racially disparaging reports notwithstanding favourable historical grades, and the unidentified universal illegitimate-birth allegation.[^29][^35][^49]

### 35. Conclusion: a real warning is not a licence for unwarranted conclusions

A rigorous Imāmī response need not deny the warning of Yūnus, vilify al-Ḥaydarī, pretend al-Kulaynī never transmitted a problematic report, or declare all extraordinary traditions authentic. Indeed, each of those devices would weaken the defence. The historical presence of fabricated material is precisely why *rijāl*, *dirāyah*, *fihrist*, textual comparison, legal *uṣūl* and Qurʾānic criticism matter.

The decisive criticism of Al-Islaah is that it **does not consistently distinguish what its sources demonstrate from what its rhetoric implies**. A documented instance of insertion becomes the foundation of a generalized copying history; the presence of suspect narrators becomes a claim that early scholars did the opposite of filtering; negative assessments of large collections become a supposed count of positive fabrications; and the presence of genuinely difficult traditions is made to bear the burden of judging an entire historical corpus. These steps are not validated merely by repeating the gravity of fabrication.

One should therefore reject two indefensible slogans. **“It occurs in *al-Kāfī*, so it must have been said by an Imam”** cannot survive careful source criticism. But neither can **“Fabricators accessed some companions' books, so the Imāmī heritage is presumptively a mass of deliberate inventions.”** The first ignores documented contamination. The second assumes its extent and surviving textual genealogy without supplying the evidence that those very problems demand.

The strongest position is deliberately demanding: establish a report by evidence proportionate to its doctrinal, historical or legal significance; refuse to convert weakness into fabrication or formal grading into certainty; and require advocates of sweeping numerical assertions to publish a reproducible account of their method. **The Imāmī corpus deserves scrutiny precisely because it contains a recoverable history of transmission and criticism—not because its authors were infallible, and not because sweeping charges are self-proving.**

---

## Editorial scope and what has not been proved

This edition directly rebuts the published Al-Islaah essay as available on 31 October 2026. It does not pretend to be a transcript of every minute of the embedded video, to establish al-Ḥaydarī's entire evolving methodology, to settle all historical doctrinal disagreements over *taḥrīf*, or to provide a fresh manuscript collation of the *uṣūl*. The reported assessments of al-Majlisī, al-Behbūdī and others are identified as such, and where a modern online grading index is used its status is specified. A definitive quantitative study of *Biḥār* or the whole *al-Kāfī* corpus remains future work.

Further source verification is warranted before classifying the present text as independently peer-reviewed or manuscript-critical. A scholarly polemic is not strengthened by hiding its outstanding research questions.


## References and source notes

[^1]: Syed Ali Hur Kamoonpuri, “How reliable is our Hadith Corpus? | Ayatullah Sayyid Kamal Al-Haydari,” Al-Islaah , original article. All attributions of claims to that website refer to its author’s public text, not necessarily to a complete transcript of the embedded video. Original article | https://al-islaah.org/article/how-reliable-is-our-hadith-corpus-ayatullah-sayyid-kamal-al-haydari/

[^2]: Sayyid Kamāl al-Ḥaydarī, “Min ahamm asbāb ʿadam al-thiqah bi-l-mawrūth al-riwāʾī (1),” official Arabic lecture transcript (December 2016). This is a separate official transcript, used to test broad attributions about his general position. Official transcript | https://alhaydari.com/ar/2016/12/58950/

[^3]: Shaykh al-Ṭūsī (preserving al-Kashshī), Ikhtiyār Maʿrifat al-Rijāl , report 401, Āl al-Bayt edition, vol. 2, p. 489. This edition paginates the report differently from editions citing vol. 1, pp. 224–225. Arabic text, p. 489 | https://ablibrary.net/book_content/b/3304/73

[^4]: Ikhtiyār Maʿrifat al-Rijāl , report 401 continued on vol. 2, p. 490; report 402 on vol. 2, p. 491. Report 401 continuation · Report 402 | https://ablibrary.net/book_content/b/3304/74 ; https://ablibrary.net/book_content/b/3304/75

[^5]: Al-Najāshī, Fihrist , entry [939], records Ibn al-Walīd’s exclusions from Nawādir al-Ḥikmah . The criticism connected with Muḥammad b. ʿĪsā b. ʿUbayd must be read in its specified transmission context; it is not an unconditional judgement that the narrator fabricated reports. Arabic source, printed p. 348 . | https://ablibrary.net/book_content/b/4826/349

[^6]: Sayyid Muḥammad Saʿīd al-Ḥakīm, al-Muḥkam fī Uṣūl al-Fiqh , vol. 3, p. 213: explicit reference to al-Kashshī’s transmission as sound through Muḥammad b. ʿĪsā from Yūnus. Primary text, p. 213 | https://books.rafed.net/view/2986/page/213

[^7]: Sayyid Kāẓim al-Ḥāʾirī, Mabāḥith al-Uṣūl , section II, part II, p. 393, preserving the argument attributed to Sayyid Muḥammad Bāqir al-Ṣadr about the possible survival of uncontaminated copies. The argument relies on the likelihood or possibility of multiple recensions, not an established collation of particular manuscripts. Official Arabic text, p. 393 . | https://www.alhaeri.org/pages/book-detail.php?bid=22&pid=393

[^8]: Al-Najāshī, Fihrist Asmāʾ Muṣannifī al-Shīʿa (commonly Rijāl al-Najāshī ), a classical directory of works and routes; the case study on p. 348 illustrates the level of historical information it can preserve. Text of entry | https://ablibrary.net/book_content/b/4826/349

[^9]: Al-Najāshī, Fihrist , entry [939], on Muḥammad b. Aḥmad b. Yaḥyā and Ibn al-Walīd’s exceptions from his transmissions; includes Ibn Nūḥ’s qualification concerning Muḥammad b. ʿĪsā b. ʿUbayd. Direct Arabic source, p. 348 | https://ablibrary.net/book_content/b/4826/349

[^10]: Al-Kulaynī, al-Kāfī , author’s introduction, in the edition edited by ʿAlī Akbar al-Ghaffārī, p. 8 (edition-specific pagination). Preface Arabic text | https://ablibrary.net/book_content/b/3249/56

[^11]: Al-Kulaynī, al-Kāfī , book of the excellence of knowledge, chapter “al-Akhdh bi-l-Sunnah wa-Shawāhid al-Kitāb,” including reports on Qurʾānic witnesses and contradictory ḥadīth. Chapter text | https://usul.ai/ar/t/kafi/59

[^12]: Al-Ṣadūq, Man Lā Yaḥḍuruhu al-Faqīh , vol. 1, author’s introduction, p. 3: “ بل قصدت إلى إيراد ما أفتي به وأحكم بصحته .” His assessment of ṣiḥḥah should not be equated automatically with every later technical definition. Direct Arabic transcription, p. 3 . | https://library.misbah-inc.com/faqih/1/3/

[^13]: Sayyid Abū al-Qāsim al-Khūʾī, Muʿjam Rijāl al-Ḥadīth , introductory discussion “Naẓrah fī Riwāyāt al-Kutub al-Arbaʿah,” rejecting blanket authentication of all four collections; hosted by al-Khūʾī Institute. Primary discussion | https://www.alkhoei.com/ar/opinion/%D9%83%D9%84%D9%8A%D8%A7%D8%AA-%D8%B9%D9%84%D9%85-%D8%A7%D9%84%D8%B1%D8%AC%D8%A7%D9%84

[^14]: Al-Sharīf al-Murtaḍā’s discussion of the limits of khabar al-wāḥid , preserved in Tafsīr al-Sharīf al-Murtaḍā (a later collected edition), and in his Rasāʾil . These references document his attributed argument; for extended methodological analysis, compare his directly authored al-Dharīʿah in a specified edition. Collected discussion · Rasāʾil, vol. 1, p. 100 . | https://lib.rafed.net/view.php?b_id=3793&page=222&type=c_fbook ; https://najafdesertlibrary.com/book/رسائل-الشريف-المرتضى/v/1/p/100

[^15]: Al-Ṭūsī, al-ʿUddah fī Uṣūl al-Fiqh , vol. 1, on evidential reliance upon different transmitters, the context of a report, trustworthiness and conflicting traditions. The cited page supports the treatment of non-Imāmī channels; it does not prove that all reports in famous books are universally sound. Arabic discussion, p. 381 . | https://books.rafed.net/view/4539/page/381

[^16]: Al-Ḥurr al-ʿĀmilī, Wasāʾil al-Shīʿa , concluding ninth benefit, “ في الاستدلال على صحة أحاديث الكتب المنقول منها ,” vol. 30, beginning p. 249 in the cited edition. This is the author’s extended argument for the reliability of the recognised source collections; it is not an independently established grading of each report. Direct Arabic text, vol. 30, p. 249 . | https://najafdesertlibrary.com/book/وسائل-الشيعة/v/30/p/249

[^17]: Sayyid ʿAlī al-Sīstānī, Qāʿidat Lā Ḍarar wa-Lā Ḍirār , p. 215, regarding the underlying consistency or conflict of a report with the Qurʾān and Sunnah, as recognised through contextual signs. Arabic primary source, p. 215 | https://ablibrary.net/book_content/b/6728/215

[^18]: Official website of Sayyid ʿAlī al-Sīstānī, answer to question 5 on the expertise needed to identify the most learned jurist, including rijāl, source-book recognition, textual intrusion, manuscript differences and editorial additions. These are methodological competencies, not a published grading of the present case studies. Official answer, question 5 . | https://www.sistani.org/arabic/qa/02082/

[^19]: Sayyid Kāẓim al-Ḥāʾirī, Mabāḥith al-Uṣūl , section II, part II, pp. 375–383, including arguments attributed to his teacher al-Ṣadr alongside al-Ḥāʾirī’s own presentation and analysis. The surrounding pages distinguish rejecting a report’s probativity from denying that it could have been uttered and address different forms of contradiction with scripture. Start of discussion, p. 375 · Classification, p. 377 . | https://www.alhaeri.org/pages/book-detail.php?bid=22&pid=375 ; https://www.alhaeri.org/pages/book-detail.php?bid=22&pid=377

[^20]: Shaykh Muḥammad Āṣif al-Muḥsinī, Mashraʿat Biḥār al-Anwār , vol. 1, p. 9; carefully distinguishes chains that are not probative from confirmed fabrication and explains the potential effects of cumulative convergence and contextual confidence. Primary text, vol. 1 p. 9 | https://ablibrary.net/book_content/b/16378/21

[^21]: Al-Muḥsinī, Mashraʿat Biḥār al-Anwār , vol. 1, p. 33, note describing the limits of inference from either apparently reliable or unreliable isnāds. Primary text, p. 33 | https://ablibrary.net/book_content/b/16378/45?lang=ar

[^22]: Al-Ṣadūq, al-Iʿtiqādāt fī Dīn al-Imāmiyyah , chapter on rejecting ghuluw and tafwīḍ , p. 97; and al-Mufīd, Taṣḥīḥ Iʿtiqādāt al-Imāmiyyah , his own discussion of ghuluw , p. 131. The quoted definition attributing divinity or prophethood to the Imams is al-Mufīd’s , not al-Majlisī’s. Al-Ṣadūq, p. 97 · Al-Mufīd, p. 131 . | https://ablibrary.net/book_content/b/4077/99 ; https://ablibrary.net/book_content/b/4078/131

[^23]: Al-Majlisī, Biḥār al-Anwār , vol. 25, p. 349 , where his own discussion criticises overly restrictive accusations of ghuluw against trustworthy transmitters and explains limits on claims of delegated creation and sustenance. The preceding pp. 346–347 contain extensive transmission of al-Mufīd’s discussion; the authors’ voices must not be conflated. Al-Majlisī, primary text, 25:349 · Al-Mufīd, direct text . | https://najafdesertlibrary.com/book/بحار-الأنوار/v/25/p/349 ; https://ablibrary.net/book_content/b/4078/131

[^24]: Shaykh Jaʿfar al-Subḥānī, Kulliyyāt fī ʿIlm al-Rijāl , p. 98, on objections of doctrinal preference against narrators, with a quotation of al-Majlisī. Primary authored text | https://books.rafed.net/view/149/page/98

[^25]: Shaykh Yūsuf al-Baḥrānī, al-Ḥadāʾiq al-Nāḍirah , vol. 1, second introductory discussion on authenticating transmitted reports and rejecting the later fourfold terminology; compare the separate chapters on textual conflict and preference. Primary volume and table of contents | https://books.rafed.net/view/2698/page/124

[^26]: Muḥaddith Ḥusayn al-Nūrī, Mustadrak al-Wasāʾil , author’s introduction, on finding reports in older, overlooked or disputed books; Khātimat al-Mustadrak , introductory sections on his sources and authorship questions. Author’s introduction · Khātimah, source analysis | https://usul.ai/ar/t/mustadrak-wasail/2 ; https://books.rafed.net/view/1458/page/59

[^27]: Jāmiʿ Aḥādīth al-Shīʿa , vol. 1, introduction, p. 22, listing principles for ordering parallel reports, noting narrator similarities and addressing suspected distortions in textual and isnād transmission. A collection assembled under al-Burūjerdī’s supervision. Editorial principles, p. 22 | https://ablibrary.net/book_content/b/1415/22?lang=ar

[^28]: Syed Ali Hur Kamoonpuri, “How Reliable Is Our Hadith Corpus?”, Al-Islaah, especially footnote 3 (lists specific controversial examples) and the surrounding discussion. Primary text or source witness . | https://al-islaah.org/article/how-reliable-is-our-hadith-corpus-ayatullah-sayyid-kamal-al-haydari/

[^29]: Al-Kulaynī, al-Kāfī, vol. 2, p. 634, no. 28 (al-Ghaffārī edition); the printed notes register the alternative reading “Hārūn b. Muslim”. Primary text or source witness . | https://ablibrary.net/book_content/b/3250/634?lang=ar

[^30]: Al-Majlisī, Mirʾāt al-ʿUqūl, vol. 12, p. 525: grading and detailed discussion of the report about the number of Qurʾānic verses. Primary text or source witness . | https://ablibrary.net/book_content/b/7175/529

[^31]: The International al-Kulaynī Conference essays, vol. 1, printed p. 97, record a transmitted textual variant in which al-Fayḍ al-Kāshānī cites “seven thousand” in al-Wāfī (cited there as vol. 19, p. 1781, report 9089/7), contrasting with the familiar “seventeen thousand” wording. This documentation does not establish which reading is original; dated manuscript collation is still needed. Secondary documentary discussion, p. 97 . | https://ablibrary.net/book_content/b/14545/101

[^32]: Al-Ṣadūq, al-Iʿtiqādāt, chapter “al-Iʿtiqād fī Mablagh al-Qurʾān”, p. 86, on the received Qurʾān and revealed material distinct from the Qurʾān. Primary text or source witness . | https://najafdesertlibrary.com/book/الاعتقادات-في-دين-الإمامية/v/1/p/86

[^33]: Al-Ḥurr al-ʿĀmilī, Tawātur al-Qurʾān, p. 118, on the seventeen-thousand narration and possible explanations of its meaning. Primary text or source witness . | https://ablibrary.net/book_content/b/13353/118

[^34]: Al-Khūʾī, al-Bayān fī Tafsīr al-Qurʾān, discussion “Ṣiyānat al-Qurʾān min al-Taḥrīf”, around pp. 197 ff., specifying distinct senses of taḥrīf and arguing against textual deficiency. Primary text or source witness . | https://najafdesertlibrary.com/book/البيان-في-تفسير-القرآن/v/1/p/197

[^35]: Al-Kulaynī, Rawḍat al-Kāfī, vol. 8, p. 113, report 55, earth/whale/water/rock/bull; abbreviated opening “Muḥammad → Aḥmad”. Primary text or source witness . | https://najafdesertlibrary.com/book/الكافي/v/8/p/113

[^36]: The Thaqalayn grading index attributes ṣaḥīḥ to al-Majlisī for al-Kāfī 8, report 55, citing Mirʾāt al-ʿUqūl 15:201 in its own edition scheme. An independently accessible digital edition places the report at Mirʾāt 25:201 , but that page does not clearly display a separate grading. Independently, Muḥammad Ḥusayn b. Qāriyāghdī states “ والسند صحيح ” in al-Biḍāʿah al-Muzjāh , vol. 2, p. 87. Al-Behbūdī’s non-inclusion in Ṣaḥīḥ al-Kāfī is a selection outcome, not a finding of fabrication. Reported al-Majlisī grading · Mirʾāt digitised text, 25:201 · Independent sanad assessment, p. 87 . | https://thaqalayn.com/chapter/8/1/55 ; https://najafdesertlibrary.com/book/مرآة-العقول-في-شرح-أخبار-آل-الرسول/v/25/p/201 ; https://ablibrary.net/book_content/b/8831/87?lang=ar

[^37]: Al-Majlisī, Biḥār al-Anwār, vol. 57, p. 79 and following, presenting an additional route via Sahl b. Ziyād that joins the sequence through Ibn Maḥbūb, and citing al-Kāfī. Primary text or source witness . | https://najafdesertlibrary.com/book/بحار-الأنوار/v/57/p/81

[^38]: Official website of Sayyid Muḥammad Ṣādiq al-Rūḥānī, question on the earth/whale/bull narration; proposes the zodiacal-sign reading as a possibility. Primary text or source witness . | https://www.imamrohani.com/ar/print/istefta/7491

[^39]: Al-Kulaynī, al-Kāfī, vol. 6, p. 246, report 14, opening clause on the elephant and the list of alleged transformations. Primary text or source witness . | https://ablibrary.net/book_content/b/3254/246?lang=ar

[^40]: Al-Majlisī, Mirʾāt al-ʿUqūl, vol. 22, p. 35, categorises report 14 as “majhūl”; this is distinct from the grading of the whale report. Primary text or source witness . | https://ablibrary.net/book_content/b/14193/35

[^41]: Al-Ṣadūq, ʿUyūn Akhbār al-Riḍā , vol. 1, p. 245, transmits a report asserting that people subjected to maskh did not leave offspring. The existence of this transmitted report is documented here; its own chain has not been authenticated in the present study . Arabic source, p. 245 . | https://ablibrary.net/book_content/b/5047/245

[^42]: Al-Najāshī, Fihrist Asmāʾ Muṣannifī al-Shīʿa, p. 174, entry 460, Zayd al-Narsī and the transmission path through Ibn Abī ʿUmayr. Primary text or source witness . | https://ablibrary.net/book_content/b/4826/175?lang=ar

[^43]: Al-Ṭūsī, al-Fihrist , p. 130, entries 299–300, states that the uṣūl of Zayd al-Narsī and Zayd al-Zarrād were not transmitted by al-Ṣadūq, and reports Ibn al-Walīd’s allegation that they were forged by Muḥammad b. Mūsā al-Hamdānī; al-Ṭūsī also reports Ibn Abī ʿUmayr’s transmission of Zayd al-Narsī’s book. The paragraph beginning “ ما ذكره قدس سره... ” belongs to a later editorial footnote , not to al-Ṭūsī’s original Fihrist text; do not treat its defence of the route as a direct assertion by al-Ṭūsī. Original text and labelled editorial footnote, p. 130 . | https://ablibrary.net/book_content/b/2684/130?lang=ar

[^44]: Muḥaddith al-Nūrī, Khātimat al-Mustadrak, p. 62 (in this edition), investigation and defence of the transmission of Zayd al-Narsī’s book. Primary text or source witness . | https://ablibrary.net/book_content/b/4399/160?lang=ar

[^45]: Al-Kulaynī, al-Kāfī, vol. 1, p. 99, chapter “Riwāyat al-Kutub wa-l-Ḥadīth”, reports 1–3, including the hadith of Muḥammad b. Muslim on transmitting by meaning. Primary text or source witness . | https://najafdesertlibrary.com/book/الكافي/v/1/p/99

[^46]: Muḥammad Āṣif al-Muḥsinī, Muʿjam al-Aḥādīth al-Muʿtabarah, vol. 1, p. 63, section “Riwāyat al-Ḥadīth bi-l-Maʿnā”; authenticates the report and discusses its possible implications. Primary text or source witness . | https://ablibrary.net/book_content/b/16370/63?lang=ar

[^47]: Al-Majlisī, Biḥār al-Anwār, vol. 2, p. 164, discussion of permissibility of transmission by meaning under conditions and the preference for transmitting wording exactly. Primary text or source witness . | https://ablibrary.net/book_content/b/1998/166?lang=ar

[^48]: Al-Kulaynī, al-Kāfī , vol. 1, book of the proof, “Birth of al-Ḥusayn,” report 3: immediate context explicitly says Fāṭimah’s distress concerned her foreknowledge of his killing. See also the Dār al-Ḥadīth transcription at Rafed, p. 505 . Arabic narration and modern grading index . | https://lib.rafed.net/view.php?b_id=825&page=505&type=c_fbook ; https://thaqalayn.com/hadith/1/4/116/3

[^49]: Al-Kulaynī, al-Kāfī , vol. 5, book of marriage, chapter 28, reports 1–3, on ethnic groups and marriage; the modern Thaqalayn index reports al-Majlisī’s “ṣaḥīḥ ʿalā al-ẓāhir” for no. 1, “mursal” for no. 2 and “ḍaʿīf ʿalā al-mashhūr” for no. 3. It also records a variant for the name Masʿadah b. Ziyād / Masʿadah b. Ṣadaqah. These are displayed gradings requiring independent edition-level checks. Primary chapter and indexed judgments . | https://thaqalayn.com/chapter/5/3/28

[^50]: Sayyid Kamāl al-Ḥaydarī, official Arabic lecture transcript (February 2018), recounting Āshtīyānī’s transmission of observations attributed to al-Burūjerdī, notably about reports on the praise and blame of places and properties of foods. This is an indirect recollection, not a direct text by al-Burūjerdī or a statistical study of all Biḥār . Official transcript . | https://alhaydari.com/ar/2018/02/64838/

[^51]: Thaqalayn’s entry for al-Kāfī , vol. 1, book of the proof, chapter 116, report 3, lists an al-Majlisī assessment as “mukhtalaf fīh” and marks it omitted from al-Behbūdī’s Ṣaḥīḥ al-Kāfī . The online display is a grading index, not an independently checked facsimile of the cited commentary. Report, chain and indexed grades . | https://thaqalayn.com/hadith/1/4/116/3

